﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.SqlServer.Server;
using MySql.Data.MySqlClient;

namespace Aula_130426
{
    internal class ConexaoBancoDeDados
    {
        MySqlConnection Conexao = new MySqlConnection();
        public MySqlCommand Comandos = new MySqlCommand();

        private string _StrSql;

        public string StrSql
        {
            get { return _StrSql; }
            set { _StrSql = value; }
        }
        
        private string strConexao = "datasource=localhost;username=root;password=;database=Produtos";

        private MySqlConnection AbrirBanco()
        {
            MySqlConnection conexao = new MySqlConnection();
            conexao.ConnectionString = strConexao;
            conexao.Open();
            return conexao;
        }

        private void FecharBanco(SqlConnection conexao)
        {
            if (conexao.State == System.Data.ConnectionState.Open)
            {
                conexao.Close();
            }
        }

        public DataSet RetornarDataSet()
        {
            MySqlDataAdapter adaptadorSql = new MySqlDataAdapter();
            DataSet conjuntoDeDados = new DataSet();

            try
            {
                Conexao = AbrirBanco();
                Comandos.CommandText = _StrSql;
                Comandos.CommandType = CommandType.Text;
                Comandos.Connection = Conexao;
                adaptadorSql.SelectCommand = Comandos;
                adaptadorSql.Fill(conjuntoDeDados);
                return (conjuntoDeDados);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                Conexao.Close();
            }
        }
    
        public MySqlDataReader retornarDataReader()
            {
                try
                {
                    Conexao = AbrirBanco();
                    Comandos.CommandText = _StrSql;
                    Comandos.CommandType = CommandType.Text;
                    Comandos.Connection = Conexao;
                    return Comandos.ExecuteReader(CommandBehavior.CloseConnection);
                }
                catch (Exception ex) {

                    throw ex;
                }

            }

        public int executarComando()
            {
                try
                {
                    Comandos.CommandText = _StrSql;
                    Comandos.CommandType = CommandType.Text;
                    Comandos.Connection = Conexao;
                    return Comandos.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    throw new Exception("Erro: " + ex.Message);
                }
                finally
                {

                    Conexao.Close();
                }
            }

    }

}
