﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace Aula_130426
{

   
    public partial class frmProdutos : Form
    {

        ConexaoBancoDeDados conexaoBD = new ConexaoBancoDeDados();
        StringBuilder comandoSql = new StringBuilder();
        DataSet conjuntoDados = new DataSet();
        DataTable tabelaDados;
        MySqlDataReader sqlDataReader;
        public frmProdutos()
        {
            InitializeComponent();
        }

        private void frmProdutos_Load(object sender, EventArgs e)
        {
            // chamar grid
        }

        private void btnIncluir_Click(object sender, EventArgs e)
        {
            comandoSql.Remove(0, comandoSql.Length);
            comandoSql.Append("insert into Produtos");
            comandoSql.Append("Codigo, Descricao, Valor, Vencimento");
            comandoSql.Append("values ");
            comandoSql.Append("@Codigo, @Descricao, @Valor, @Vencimento");

            conexaoBD.Comandos.Parameters.Clear();
            conexaoBD.Comandos.Parameters.AddWithValue("@Codigo", txtCodigo.Text);
            conexaoBD.Comandos.Parameters.AddWithValue("@Descricao", txtDescricao.Text);
            conexaoBD.Comandos.Parameters.AddWithValue("@Valor", txtValor.Text);
            conexaoBD.Comandos.Parameters.AddWithValue("@Vencimento", dtpVencimento.Text);

            conexaoBD.StrSql = comandoSql.ToString();

            if (conexaoBD.executarComando() > 0)
            {
                MessageBox.Show("Produto incluido com sucesso");
                // chamar grid
            } else
            {
                MessageBox.Show("Erro na inclusão do produto");
            }
        }
    }
}
